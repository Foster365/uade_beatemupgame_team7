﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    //Public variables
    public float movementSpeed;
    public float jumpForce;
    
    public int maxLife = 100;
    public int damage = 10;
    //

    // Private variables
    int _currentLife;

    bool _grounded = false;

    Rigidbody _rigidbody;
    Animator _animator;
    //
    private void Awake()
    {

        _rigidbody = GetComponent<Rigidbody>();
        _animator = GetComponent<Animator>();
        
    }

    private void Start()
    {
        _currentLife = maxLife;
    }

    // private void Update()
    // {
    //     CheckInputs();
    //     CheckGround();
    // }

    public void CheckInputs()
    {
        
        _rigidbody.velocity = Input.GetAxis("Vertical") * movementSpeed * Time.deltaTime * transform.forward;
        _rigidbody.velocity += Input.GetAxis("Horizontal") * movementSpeed * Time.deltaTime * transform.right;

    }

    public void CheckJump()
    {

        float yVelocity = _rigidbody.velocity.y;

        _rigidbody.velocity += Vector3.up * yVelocity;

        if (Input.GetKeyDown(KeyCode.Space)) //El error del _animator.SetTrigger() está acá!
        {
            _rigidbody.AddForce(jumpForce * transform.up, ForceMode.Impulse);
        }

    }

    private void CheckGround()
    {
        //Operador ternario
        //_grounded = Physics.Raycast(transform.position, -transform.up, 0.1f, 1 << LayerMask.NameToLayer("Ground")) ?  true : false;
        
        _grounded = Physics.Raycast(transform.position, -transform.up, 0.1f, 1 << LayerMask.NameToLayer("Ground"));
    }
    
    private void Shoot()
    {
        //Attack algorithm
    }
    
    public void TakeDamage(int damage)
    {

        _currentLife -= damage;

        //hpBar.fillAmount = _currentLife / maxLife;

        if(_currentLife <= 0) Die();

    }

    private void Die()
    {
        //Recuerden el "using UnityEngine.SceneManager;" para habilitar esto
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
