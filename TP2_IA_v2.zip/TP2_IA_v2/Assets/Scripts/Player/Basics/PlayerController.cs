﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public Player player;
    PlayerAnimation _playerAnim;
    FSM<string> _playerFSM;

    private void Awake() {

        player=GetComponent<Player>();
        _playerAnim=GetComponent<PlayerAnimation>();
        
    }
    private void Start() {

        _playerFSM=new FSM<string>();

        IdleStatePlayer<string> idleStatePlayer=new IdleStatePlayer<string>(_playerAnim);
        MoveStatePlayer<string> moveStatePlayer=new MoveStatePlayer<string>(player);
        JumpStatePlayer<string> jumpStatePlayer=new JumpStatePlayer<string>(player);

        idleStatePlayer.AddTransition("MoveState", moveStatePlayer);
        moveStatePlayer.AddTransition("IdleState", idleStatePlayer);
        // moveStatePlayer.AddTransition("JumpState", jumpStatePlayer);
        // jumpStatePlayer.AddTransition("MoveState", moveStatePlayer);
        idleStatePlayer.AddTransition("JumpState", jumpStatePlayer);
        jumpStatePlayer.AddTransition("IdleState", idleStatePlayer);
        _playerFSM.SetInit(idleStatePlayer);
    }

    private void Update() {
        var h=Input.GetAxis("Horizontal");
        var y=Input.GetAxis("Vertical");
        // var j=Input.GetAxis("Jump");

        if(h!=0||y!=0)
            _playerFSM.Transition("MoveState");
        else if(Input.GetKeyDown(KeyCode.Space))
            _playerFSM.Transition("JumpState");
        else if (h==0&&y==0)
            _playerFSM.Transition("IdleState");
        _playerFSM.OnUpdate();
    }
}
