﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JumpStatePlayer<T>:FSMState<T>
{
    Player _player;
    
    public JumpStatePlayer(Player player)
    {
        _player=player;
    }

    public override void Awake() {
        
        Debug.Log("JumpState Awake");
    }

    public override void Execute()
    {
        _player.CheckJump();
        Debug.Log("JumpState Execute");
    }

    public override void Sleep()
    {
        Debug.Log("JumpState Sleep");
    }
}
