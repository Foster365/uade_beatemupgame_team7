﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveStatePlayer<T>:FSMState<T>
{
    Player _player;
    public MoveStatePlayer(Player player)
    {
        _player=player;
    }

    public override void Awake()
    {
        Debug.Log("Move State Awake");
    }

    public override void Execute()
    {
        _player.CheckInputs();
        Debug.Log("Move State Execute");
    }

    public override void Sleep()
    {
        Debug.Log("Move State Sleep");
    }
}
