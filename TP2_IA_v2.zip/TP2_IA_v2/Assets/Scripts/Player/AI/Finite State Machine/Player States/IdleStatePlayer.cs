﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IdleStatePlayer<T> : FSMState<T>
{
    PlayerAnimation playerAnimation;
    public IdleStatePlayer(PlayerAnimation _playerAnimation)
    {
        playerAnimation=_playerAnimation;
    }

    public override void Awake()
    {
        Debug.Log("Idle State Awake");
    }

    public override void Execute()
    {
        Debug.Log("Idle State Execute");
    }

    public override void Sleep()
    {
        Debug.Log("Idle State Sleep");
    }

}
